const SALES_KEY = "s15_sales";

export const saveSale = (sale) => {
    // 1. Obtenemos las ventas guardadas o un array vacío
    const sales = JSON.parse(localStorage.getItem(SALES_KEY)) || [];
    
    // 2. Agregamos la nueva venta
    sales.push(sale);
    
    // 3. Guardamos de nuevo en el navegador
    localStorage.setItem(SALES_KEY, JSON.stringify(sales));
};

export const getSales = () => {
    // Retorna el historial, ordenado del más reciente al más antiguo
    const sales = JSON.parse(localStorage.getItem(SALES_KEY)) || [];
    return sales.reverse();
};