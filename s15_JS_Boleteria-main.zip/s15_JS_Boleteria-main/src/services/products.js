const PRODUCTS_KEY = 's15_products';

// Obtener productos (si no existen en memoria, los carga del JSON)
export const getProducts = async () => {
    // 1. Verificamos si ya existen en LocalStorage
    const storedProducts = localStorage.getItem(PRODUCTS_KEY);

    if (storedProducts) {
        return JSON.parse(storedProducts);
    } else {
        // 2. Si es la primera vez, cargamos desde el JSON
        try {
            const response = await fetch('/products.json');
            const data = await response.json();
            // Guardamos en localStorage para futuras ediciones
            localStorage.setItem(PRODUCTS_KEY, JSON.stringify(data));
            return data;
        } catch (error) {
            console.error("Error cargando productos iniciales:", error);
            return [];
        }
    }
};

// Actualizar el stock de un producto
export const updateProductStock = (productId, newStock) => {
    const products = JSON.parse(localStorage.getItem(PRODUCTS_KEY)) || [];
    
    const updatedProducts = products.map(p => {
        if (p.id === productId) {
            return { ...p, stock: parseInt(newStock) };
        }
        return p;
    });

    localStorage.setItem(PRODUCTS_KEY, JSON.stringify(updatedProducts));
    return updatedProducts;
};

//agregar producto
export const addProduct = (productData) => {
    const products = JSON.parse(localStorage.getItem(PRODUCTS_KEY)) || [];

    // Generamos un ID simple (ej: P999) usando un número aleatorio para no complicarnos
    const newId = "P" + Math.floor(Math.random() * 10000);

    const newProduct = {
        id: newId,
        nombre: productData.nombre,
        precio: parseFloat(productData.precio), // Aseguramos que sea número
        stock: parseInt(productData.stock)      // Aseguramos que sea entero
    };

    // Agregamos al array
    products.push(newProduct);

    // Guardamos
    localStorage.setItem(PRODUCTS_KEY, JSON.stringify(products));

    return products; // Devolvemos la lista actualizada
};

//eliminar producto
export const deleteProduct = (productId) => {
    let products = JSON.parse(localStorage.getItem(PRODUCTS_KEY)) || [];
    
    // Filtramos para quedarnos con todos MENOS el que queremos borrar
    const updatedProducts = products.filter(p => p.id !== productId);

    // Guardamos la nueva lista
    localStorage.setItem(PRODUCTS_KEY, JSON.stringify(updatedProducts));

    return updatedProducts;
};
