const API_TOKEN = "sk_11035.aKumNBGFhdpwqPYj7Z9dxrDUHQ3IJ6Sx";

const RENIEC_API_URL = "/v1/reniec/dni";
const SUNAT_API_URL = "/v1/sunat/ruc";

const EXCHANGE_RATE_API_URL = "/v1/tipo-cambio/sunat";

const fetchWithAuth = async (url) => {

    const response = await fetch(url, {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
            // Aquí se envía el token de forma segura
            'Authorization': `Bearer ${API_TOKEN}`
        }
    });

    if (!response.ok) {
        // Si la API devuelve un error (404, 401, 500, etc.)
        const errorData = await response.json();
        console.error("Error de la API:", errorData);
        throw new Error(errorData.message || "Error al consultar la API");
    }

    return response.json();
};

//==================
// API DE RENIEC
//==================

export const fetchReniecData = async (dni) => {
  console.log(`Buscando DNI: ${dni} en Decolecta...`);
  
  // Construye la URL dinámicamente
  const url = `${RENIEC_API_URL}?numero=${dni}`;
  
  const data = await fetchWithAuth(url);

  const nombres = data.first_name || "";
  const apellidos = `${data.first_last_name || ""} ${data.second_last_name || ""}`.trim();

  if (!nombres || !apellidos) {
     console.warn("Respuesta de API incompleta:", data);
     throw new Error("Respuesta de API incompleta o DNI no válido.");
  }

  return { nombres, apellidos };
};


//==================
// API DE SUNAT
//==================

export const fetchSunatData = async (ruc) => {
    console.log(`Buscando RUC: ${ruc} en Decolecta...`);

    const url = `${SUNAT_API_URL}?numero=${ruc}`;

    const data = await fetchWithAuth(url);

    // Componente BillingForm.js espera: { razonSocial }
    // Decolecta devuelve: { razon_social }

    const razonSocial = data.razon_social || data.razonSocial;

    if (!razonSocial) {
        console.warn("Respuesta de API incompleta o RUC no válido:", data);
        throw new Error("Respuesta de API incompleta o RUC no válido.");
    }

    return { razonSocial }; // El componente espera 'razonSocial' (camelCase)
};


//=====================
// API TIPO DE CAMBIO
//=====================

export const fetchExchangeRate = async () => {
  console.log("Obteniendo tipo de cambio de Decolecta...");

  const url = EXCHANGE_RATE_API_URL;

  try {
    const data = await fetchWithAuth(url);

    // Convertimos el string a número y usamos 'sell_price'
    const tipoCambioVenta = parseFloat(data.sell_price); 

    if (!tipoCambioVenta || tipoCambioVenta <= 0) {
      console.error("Respuesta de API de tipo de cambio no válida:", data);
      throw new Error("Tipo de cambio 'venta' no es válido.");
    }

    // El componente BillingForm.js multiplica: TotalSoles * rate = TotalDolares
    // (Ej: 100 Soles * 0.27 = 27 Dólares)
    // Para que esta fórmula funcione, debemos devolver (1 / tipoCambioVenta)
    // (Ej: 1 / 3.552 = 0.2815)
    // Así, el cálculo en BillingForm sigue siendo:
    // (100 Soles * 0.2815 = 28.15 Dólares)
    return 1 / tipoCambioVenta;

  } catch (error) {
    console.error("Error al obtener tipo de cambio:", error);
    // Retornamos un valor por defecto si falla
    // 1 / 3.75 (un valor de respaldo razonable)
    return 0.266; 
  }
};