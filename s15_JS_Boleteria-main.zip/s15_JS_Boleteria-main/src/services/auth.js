const USERS_KEY = "s15_users";

// Simula el registro guardando en localStorage
export const registerUser = (userData) => {
  return new Promise((resolve, reject) => {
    const users = JSON.parse(localStorage.getItem(USERS_KEY)) || [];

    // Validar si el usuario o dni ya existe
    const userExists = users.find(u => u.usuario === userData.usuario || u.dni === userData.dni);

    if (userExists) {
      reject(new Error("El usuario o DNI ya están registrado!!"));
    } else {
      users.push(userData);
      localStorage.setItem(USERS_KEY, JSON.stringify(users));
      resolve({ ...userData });
    }
  });
};

// Simula el login leyendo de localStorage
export const loginUser = (username, password) => {
  return new Promise((resolve, reject) => {
    const users = JSON.parse(localStorage.getItem(USERS_KEY)) || [];

    const user = users.find(u => u.usuario === username && u.contraseña === password);

    if (user) {
      // Guardamos el usuario logeado en sessionStorage para mantener la sesión
      sessionStorage.setItem("s15_session", JSON.stringify(user));
      resolve(user);
    } else {
      reject(new Error("Usuario o contraseña incorrectos."));
    }
  });
};

// Cierra la sesión
export const logoutUser = () => {
  sessionStorage.removeItem("s15_session");
};

// Obtiene la sesión actual
export const getCurrentUser = () => {
  const user = sessionStorage.getItem("s15_session");
  return user ? JSON.parse(user) : null;
};