import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { getProducts, updateProductStock, addProduct, deleteProduct } from '../services/products';

const Products = () => {
    const [products, setProducts] = useState([]);
    const navigate = useNavigate();

    // Estados para el Modal y el Formulario
    const [showModal, setShowModal] = useState(false);
    const [newProduct, setNewProduct] = useState({
        nombre: '',
        precio: '',
        stock: ''
    });

    // Carga inicial de productos
    useEffect(() => {
        const loadProducts = async () => {
            const data = await getProducts();
            setProducts(data);
        };
        loadProducts();
    }, []);

    // --- FUNCIONES (QUE FALTABAN) ---

    // 1. Manejar cambio de stock (+/-)
    const handleStockChange = (id, currentStock, amount) => {
        const newStock = currentStock + amount;
        if (newStock < 0) return; // No permitir negativos

        const updatedList = updateProductStock(id, newStock);
        setProducts(updatedList);
    };

    // 2. Manejar inputs del formulario (Nuevo Producto)
    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setNewProduct({ ...newProduct, [name]: value });
    };

    // 3. Guardar el nuevo producto
    const handleSaveProduct = () => {
        if (!newProduct.nombre || !newProduct.precio || !newProduct.stock) {
            alert("Por favor completa todos los campos.");
            return;
        }

        const updatedList = addProduct(newProduct);
        setProducts(updatedList);
        
        // Limpiar y cerrar
        setNewProduct({ nombre: '', precio: '', stock: '' });
        setShowModal(false);
    };

    // 4. Eliminar producto
    const handleDelete = (id) => {
        if (window.confirm("¿Estás seguro de que quieres eliminar este producto?")) {
            const updatedList = deleteProduct(id);
            setProducts(updatedList);
        }
    };

    // --- VISTA (JSX) ---
    return (
        <div className="main-container">
            <div className="d-flex justify-content-between align-items-center mb-4">
                <h2 className="text-primary"><i className="bi bi-box-seam"></i> Gestión de Productos</h2>
                
                <div>
                    <button className="btn btn-success me-2" onClick={() => setShowModal(true)}>
                        <i className="bi bi-plus-circle"></i> Nuevo Producto
                    </button>
                    <button className="btn btn-secondary" onClick={() => navigate('/dashboard')}>
                        &larr; Volver
                    </button>
                </div>
            </div>

            <div className="table-responsive shadow-sm rounded">
                <table className="table table-hover align-middle">
                    <thead className="table-light">
                        <tr>
                            <th>ID</th>
                            <th>Producto</th>
                            <th className="text-end">Precio (S/)</th>
                            <th className="text-center">Stock Actual</th>
                            <th className="text-center">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        {products.map((product) => (
                            <tr key={product.id}>
                                <td><span className="badge bg-secondary">{product.id}</span></td>
                                <td className="fw-bold">{product.nombre}</td>
                                <td className="text-end">S/ {product.precio.toFixed(2)}</td>
                                <td className="text-center">
                                    <span className={`badge ${product.stock < 10 ? 'bg-danger' : 'bg-success'} fs-6`}>
                                        {product.stock} un.
                                    </span>
                                </td>
                                <td className="text-center">
                                    <div className="d-flex justify-content-center gap-2">
                                        {/* Botones de Stock */}
                                        <div className="btn-group" role="group">
                                            <button 
                                                className="btn btn-outline-secondary btn-sm" 
                                                onClick={() => handleStockChange(product.id, product.stock, -1)}
                                                title="Disminuir Stock"
                                            >
                                                <i className="bi bi-dash-lg"></i>
                                            </button>
                                            <button 
                                                className="btn btn-outline-secondary btn-sm" 
                                                onClick={() => handleStockChange(product.id, product.stock, 1)}
                                                title="Aumentar Stock"
                                            >
                                                <i className="bi bi-plus-lg"></i>
                                            </button>
                                        </div>

                                        {/* Botón Eliminar */}
                                        <button 
                                            className="btn btn-danger btn-sm" 
                                            onClick={() => handleDelete(product.id)}
                                            title="Eliminar Producto"
                                        >
                                            <i className="bi bi-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>

            {/* Modal para Nuevo Producto */}
            {showModal && (
                <div className="modal show-custom" style={{ display: 'block' }} tabIndex="-1">
                    <div className="modal-dialog">
                        <div className="modal-content">
                            <div className="modal-header bg-primary text-white">
                                <h5 className="modal-title">Registrar Nuevo Producto</h5>
                                <button type="button" className="btn-close btn-close-white" onClick={() => setShowModal(false)}></button>
                            </div>
                            <div className="modal-body">
                                <form>
                                    <div className="mb-3">
                                        <label className="form-label">Nombre del Producto</label>
                                        <input 
                                            type="text" 
                                            className="form-control" 
                                            name="nombre" 
                                            value={newProduct.nombre} 
                                            onChange={handleInputChange} 
                                            placeholder="Ej: Galleta Soda"
                                        />
                                    </div>
                                    <div className="row">
                                        <div className="col-md-6 mb-3">
                                            <label className="form-label">Precio (S/)</label>
                                            <input 
                                                type="number" 
                                                className="form-control" 
                                                name="precio" 
                                                value={newProduct.precio} 
                                                onChange={handleInputChange} 
                                                step="0.10"
                                            />
                                        </div>
                                        <div className="col-md-6 mb-3">
                                            <label className="form-label">Stock Inicial</label>
                                            <input 
                                                type="number" 
                                                className="form-control" 
                                                name="stock" 
                                                value={newProduct.stock} 
                                                onChange={handleInputChange} 
                                            />
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <div className="modal-footer">
                                <button type="button" className="btn btn-secondary" onClick={() => setShowModal(false)}>Cancelar</button>
                                <button type="button" className="btn btn-primary" onClick={handleSaveProduct}>Guardar Producto</button>
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default Products;