import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { getSales } from '../services/sales';
import { Receipt } from './Receipt';

// 1. Importamos las librerías de descarga real
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';

const SalesHistory = () => {
    const [sales, setSales] = useState([]);
    const [selectedSale, setSelectedSale] = useState(null);
    const [isDownloading, setIsDownloading] = useState(false); // Para mostrar "Descargando..."
    
    const navigate = useNavigate();
    const componentRef = useRef();

    useEffect(() => {
        setSales(getSales());
    }, []);

    // 2. Nueva función para descargar PDF Directo
    const handleDownloadPDF = async () => {
        const input = componentRef.current;
        if (!input) return;

        setIsDownloading(true);

        try {
            // Capturamos el diseño del recibo como una imagen de alta calidad
            const canvas = await html2canvas(input, {
                scale: 2, // Mejora la calidad del texto
                useCORS: true, // Ayuda si hay imágenes externas
                backgroundColor: '#ffffff' // Fondo blanco asegurado
            });

            // Convertimos la imagen a PDF
            const imgData = canvas.toDataURL('image/png');
            const pdf = new jsPDF('p', 'mm', 'a4');
            
            // Calculamos el ancho y alto para que encaje en A4
            const pdfWidth = pdf.internal.pageSize.getWidth();
            const pdfHeight = (canvas.height * pdfWidth) / canvas.width;

            pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
            
            // Nombre del archivo: Boleta_12345.pdf
            const fileName = `${selectedSale.tipo}_${selectedSale.cliente.doc}.pdf`;
            pdf.save(fileName);
        } catch (error) {
            console.error("Error generando PDF:", error);
            alert("Hubo un error al generar el PDF.");
        } finally {
            setIsDownloading(false);
        }
    };

    // --- VISTA 1: DETALLE DE LA VENTA (PANTALLA COMPLETA) ---
    if (selectedSale) {
        return (
            <div className="main-container">
                <div className="d-flex justify-content-between align-items-center mb-4 border-bottom pb-3">
                    <div>
                        <h2 className="text-primary fw-bold mb-0">
                            <i className="bi bi-eye"></i> Visualizando {selectedSale.tipo}
                        </h2>
                        <small className="text-muted">ID Transacción: {selectedSale.id}</small>
                    </div>
                    <div>
                        <button className="btn btn-outline-secondary me-2" onClick={() => setSelectedSale(null)}>
                            &larr; Volver a la Lista
                        </button>
                        
                        {/* Botón de Descarga Real */}
                        <button 
                            className="btn btn-danger" 
                            onClick={handleDownloadPDF} 
                            disabled={isDownloading}
                        >
                            {isDownloading ? (
                                <span><i className="bi bi-hourglass-split"></i> Generando...</span>
                            ) : (
                                <span><i className="bi bi-file-pdf-fill"></i> Descargar PDF</span>
                            )}
                        </button>
                    </div>
                </div>

                <div className="bg-light p-4 rounded border d-flex justify-content-center" style={{ minHeight: '500px' }}>
                    {/* El div blanco tiene un padding fijo para que el PDF salga con márgenes */}
                    <div className="bg-white shadow-sm p-4" style={{ width: '100%', maxWidth: '800px' }}>
                        {/* IMPORTANTE: El ref va aquí para capturar SOLO el recibo */}
                        <div ref={componentRef}>
                            <Receipt sale={selectedSale} />
                        </div>
                    </div>
                </div>
            </div>
        );
    }

    // --- VISTA 2: TABLA DE HISTORIAL (Igual que antes) ---
    return (
        <div className="main-container">
            <div className="d-flex justify-content-between align-items-center mb-4">
                <h2 className="text-primary"><i className="bi bi-clock-history"></i> Historial de Ventas</h2>
                <button className="btn btn-secondary" onClick={() => navigate('/dashboard')}>
                    &larr; Volver al Dashboard
                </button>
            </div>

            <div className="table-responsive shadow-sm rounded">
                <table className="table table-hover align-middle">
                    <thead className="table-light">
                        <tr>
                            <th>Fecha</th>
                            <th>Tipo</th>
                            <th>Cliente (Doc)</th>
                            <th className="text-end">Total</th>
                            <th className="text-center">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        {sales.length === 0 ? (
                            <tr>
                                <td colSpan="5" className="text-center text-muted p-4">
                                    No hay ventas registradas aún.
                                </td>
                            </tr>
                        ) : (
                            sales.map((sale) => (
                                <tr key={sale.id} style={{ cursor: 'pointer' }} onClick={() => setSelectedSale(sale)}>
                                    <td><small>{sale.fecha}</small></td>
                                    <td>
                                        <span className={`badge ${sale.tipo === 'Factura' ? 'bg-primary' : 'bg-success'}`}>
                                            {sale.tipo}
                                        </span>
                                    </td>
                                    <td>
                                        {sale.cliente.nombres.split(' ')[0]} <small className='text-muted'>({sale.cliente.doc})</small>
                                    </td>
                                    <td className="text-end fw-bold text-success">S/ {sale.totalSoles.toFixed(2)}</td>
                                    <td className="text-center">
                                        <button 
                                            className="btn btn-outline-primary btn-sm"
                                            onClick={(e) => {
                                                e.stopPropagation();
                                                setSelectedSale(sale);
                                            }}
                                        >
                                            <i className="bi bi-eye"></i> Ver Detalle
                                        </button>
                                    </td>
                                </tr>
                            ))
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default SalesHistory;