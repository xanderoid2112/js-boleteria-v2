import React from 'react';
import { useNavigate } from 'react-router-dom';

const Dashboard = ({ user, onLogout }) => {
    const navigate = useNavigate();

    const handleLogout = () => {
        onLogout();
        navigate('/login');
    };

    return (
        <div className="main-container p-0" style={{ overflow: 'hidden' }}>
            {/* === MENÚ DE NAVEGACIÓN (NAVBAR) === */}
            <nav className="navbar navbar-expand-lg navbar-light bg-light px-4 border-bottom">
                <div className="container-fluid">
                    <span className="navbar-brand fw-bold text-primary">
                        <i className="bi bi-shop me-2"></i> Mi Bodegita
                    </span>

                    {/* Botón para móviles (hamburguesa) */}
                    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                        <span className="navbar-toggler-icon"></span>
                    </button>

                    <div className="collapse navbar-collapse" id="navbarNav">
                        <ul className="navbar-nav me-auto mb-2 mb-lg-0">
                            <li className="nav-item">
                                <a className="nav-link active" aria-current="page" href="#">Inicio</a>
                            </li>

                            <li className="nav-item">
                                <button className="nav-link btn btn-link" onClick={() => navigate('/history')}>
                                    Registro
                                </button> </li>

                            <li className="nav-item">
                                <button className="nav-link btn btn-link" onClick={() => navigate('/products')}>
                                    Productos
                                </button>
                            </li>

                            <li className="nav-item">
                                <button className="nav-link btn btn-link" onClick={() => navigate('/stats')}>
                                    Estadísticas
                                </button>
                            </li>


                            {/* Menú Desplegable de Facturación */}
                            <li className="nav-item dropdown">
                                <a className="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                                    Facturación
                                </a>
                                <ul className="dropdown-menu">
                                    <li>
                                        <button className="dropdown-item" onClick={() => navigate('/billing/boleta')}>
                                            <i className="bi bi-receipt me-2"></i> Nueva Boleta
                                        </button>
                                    </li>
                                    <li>
                                        <button className="dropdown-item" onClick={() => navigate('/billing/factura')}>
                                            <i className="bi bi-file-earmark-text me-2"></i> Nueva Factura
                                        </button>
                                    </li>
                                </ul>
                            </li>
                        </ul>

                        {/* Sección de Usuario a la derecha */}
                        <div className="d-flex align-items-center">
                            <span className="me-3 text-muted">
                                <i className="bi bi-person-circle me-1"></i> {user.nombres}
                            </span>
                            <button className="btn btn-outline-danger btn-sm" onClick={handleLogout}>
                                Salir
                            </button>
                        </div>
                    </div>
                </div>
            </nav>

            {/* === CONTENIDO DE LA PÁGINA (SOBRE LA EMPRESA) === */}
            <div className="container p-5">
                {/* Cabecera de Bienvenida */}
                <div className="text-center mb-5">
                    <h1 className="display-5 fw-bold text-dark">Bienvenido a la Intranet</h1>
                    <p className="lead text-muted">Sistema de Gestión de Ventas e Inventario - Sede Ica</p>
                    <hr className="my-4" />
                </div>

                {/* Información Corporativa (Misión / Visión) */}
                <div className="row align-items-center g-5">
                    <div className="col-md-6">
                        <div className="h-100 p-4 bg-light border rounded-3 shadow-sm">
                            <h3 className="text-primary"><i className="bi bi-building"></i> Quiénes Somos</h3>
                            <p>
                                "Mi Bodegita" es una empresa líder en el sector retail, comprometida con ofrecer productos de primera necesidad
                                a precios accesibles para todas las familias peruanas. Fundada en 2020, nos hemos caracterizado
                                por nuestra atención rápida y tecnología de vanguardia.
                            </p>
                        </div>
                    </div>
                    <div className="col-md-6">
                        <div className="h-100 p-4 bg-light border rounded-3 shadow-sm">
                            <h3 className="text-success"><i className="bi bi-bullseye"></i> Nuestra Misión</h3>
                            <p>
                                Brindar una experiencia de compra ágil y segura, integrando sistemas de facturación electrónica
                                que faciliten la vida de nuestros clientes y aseguren la transparencia en cada transacción.
                            </p>
                        </div>
                    </div>
                </div>

                {/* Pie de página simple */}
                <footer className="mt-5 pt-3 text-center text-muted border-top">
                    <small>&copy; 2025 Mi Bodegita S.A.C. - Todos los derechos reservados.</small>
                </footer>
            </div>
        </div>
    );
};

export default Dashboard;