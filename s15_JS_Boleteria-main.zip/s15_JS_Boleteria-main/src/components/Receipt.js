import React from 'react';

// Usamos React.forwardRef para permitir que librerías externas (como react-to-print)
// accedan a este componente para imprimirlo.
export const Receipt = React.forwardRef(({ sale }, ref) => {
    if (!sale) return null;

    const { fecha, tipo, cliente, items, totalSoles, totalDolares } = sale;
    const esFactura = tipo === 'Factura';

    const calculateSubtotal = (item) => item.precio * item.cantidad;

    return (
        // Este div con el 'ref' es lo que se imprimirá en el PDF
        <div ref={ref} className="p-4 bg-white" style={{ maxWidth: '850px', margin: 'auto' }}>
            {/* Encabezado del Ticket */}
            <div className="text-center mb-4">
                <h4 className="fw-bold text-primary"> "MI BODEGITA"</h4>
                <p className="mb-0">RUC: 20123456789</p>
                <p className="mb-0">Calle Lima 123, Ica</p>
                <h5 className="mt-3 fw-bold border p-2 d-inline-block">
                    {esFactura ? 'FACTURA ELECTRÓNICA' : 'BOLETA DE VENTA ELECTRÓNICA'}
                </h5>
                <br />
                <small className="text-muted">Fecha de Emisión: {fecha}</small>
            </div>

            {/* Datos del Cliente */}
            <div className="border-top border-bottom py-3 mb-3 bg-light ps-3 pe-3 rounded">
                <div className="row">
                    <div className="col-sm-8">
                        <strong>Cliente:</strong> {cliente.nombres} {cliente.apellidos}
                    </div>
                    <div className="col-sm-4 text-sm-end">
                        <strong>{esFactura ? 'RUC' : 'DNI'}:</strong> {cliente.doc}
                    </div>
                </div>
            </div>

            {/* Tabla de Productos */}
            <table className="table table-striped">
                <thead className="table-dark">
                    <tr>
                        <th>Cant.</th>
                        <th>Producto</th>
                        <th className="text-end">P.Unit</th>
                        <th className="text-end">Importe</th>
                    </tr>
                </thead>
                <tbody>
                    {items.map((item) => (
                        <tr key={item.id}>
                            <td>{item.cantidad}</td>
                            <td>{item.nombre}</td>
                            <td className="text-end">{item.precio.toFixed(2)}</td>
                            <td className="text-end">{calculateSubtotal(item).toFixed(2)}</td>
                        </tr>
                    ))}
                </tbody>
            </table>

            {/* Totales */}
            <div className="row mt-4">
                <div className="col-sm-7">
                </div>
                <div className="col-sm-5 text-end">
                    <p className="mb-1">Op. Gravada: S/ {(totalSoles / 1.18).toFixed(2)}</p>
                    <p className="mb-1">I.G.V. (18%): S/ {(totalSoles - (totalSoles / 1.18)).toFixed(2)}</p>
                    <h3 className="fw-bold text-primary border-top pt-2">TOTAL: S/ {totalSoles.toFixed(2)}</h3>
                    <small className="text-muted">Equiv. Dólares: $ {totalDolares.toFixed(2)}</small>
                </div>
            </div>
            <div className="text-center mt-5 text-muted">
                <small>Gracias por su preferencia. ¡Vuelva pronto!</small>
            </div>
        </div>
    );
});