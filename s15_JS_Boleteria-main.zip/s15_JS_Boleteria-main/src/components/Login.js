import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { loginUser } from '../services/auth';

const Login = ({ onLoginSuccess }) => {
    // HOOK: useState
    // Se usa para manejar el estado de los inputs del formulario y los errores
    const [usuario, setUsuario] = useState('');
    const [contraseña, setContraseña] = useState('');
    const [error, setError] = useState('');
    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');

        try {
            const user = await loginUser(usuario, contraseña);
            onLoginSuccess(user); // Informa al App.js que el login fue exitoso
            navigate('/dashboard'); // Redirige al dashboard
        } catch (err) {
            setError(err.message);
        }
    };

    return (
        <div className="main-container">
            <h2 className="text-center text-primary mb-4">Iniciar Sesión</h2>
            <form onSubmit={handleSubmit}>
                {error && <div className="alert alert-danger">{error}</div>}

                <div className="mb-3">
                    <label htmlFor="usuario" className="form-label">Usuario</label>
                    <input
                        type="text"
                        className="form-control"
                        id="usuario"
                        value={usuario}
                        onChange={(e) => setUsuario(e.target.value)}
                        required
                    />
                </div>

                <div className="mb-3">
                    <label htmlFor="contraseña" className="form-label">Contraseña</label>
                    <input
                        type="password"
                        className="form-control"
                        id="contraseña"
                        value={contraseña}
                        onChange={(e) => setContraseña(e.target.value)}
                        required
                    />
                </div>

                <div className="d-grid gap-2">
                    <button type="submit" className="btn btn-primary btn-lg">Ingresar</button>
                </div>
            </form>
            <div className="text-center mt-3">
                <p>¿No tienes cuenta? <Link to="/register">Regístrate aquí</Link></p>
            </div>
        </div>
    );
};

export default Login;