import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { fetchReniecData, fetchSunatData, fetchExchangeRate } from '../services/api';
import { saveSale } from '../services/sales';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf'

const BillingForm = () => {
    // HOOK: useParams
    const { tipo } = useParams();
    const navigate = useNavigate();
    const esFactura = tipo === 'factura';
    const ticketRef = useRef();

//PDF
const handleDownloadPDF = async () => {
        const input = ticketRef.current;
        if (!input) return;

        try {
            const canvas = await html2canvas(input, {
                scale: 2,
                useCORS: true,
                backgroundColor: '#ffffff'
            });

            const imgData = canvas.toDataURL('image/png');
            const pdf = new jsPDF('p', 'mm', 'a4');
            
            const pdfWidth = pdf.internal.pageSize.getWidth();
            const pdfHeight = (canvas.height * pdfWidth) / canvas.width;

            pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
            
            // Nombre del archivo: Boleta_DNI_Fecha.pdf
            const fileName = `${esFactura ? 'Factura' : 'Boleta'}_${client.doc}.pdf`;
            pdf.save(fileName);

        } catch (error) {
            console.error("Error generando PDF:", error);
            alert("Hubo un error al generar el PDF.");
        }
    };

    // --- ESTADOS (HOOKS: useState) ---
    // Estado para los datos del cliente
    const [client, setClient] = useState({
        doc: '', // DNI o RUC
        nombres: '',
        apellidos: '', // O Razón Social
    });
    const [namesDisabled, setNamesDisabled] = useState(false);
    const [loadingClient, setLoadingClient] = useState(false);

    // Para manejar errores de API de cliente
    const [clientError, setClientError] = useState('');

    // Estado para los productos
    const [products, setProducts] = useState([]);
    const [selectedProductId, setSelectedProductId] = useState('');

    // Estado para el carrito
    const [cart, setCart] = useState([]);

    // Estado para finanzas
    const [exchangeRate, setExchangeRate] = useState(0);

    //Estado para controlar modal de boleta/factura
    const [showModal, setShowModal] = useState(false);

    // EFECTOS (HOOKS: useEffect)

    // HOOK: useEffect (Carga inicial)
    useEffect(() => {
        // Cargar productos desde el JSON
        fetch('/products.json')
            .then(res => res.json())
            .then(data => {
                setProducts(data);
                if (data.length > 0) {
                    setSelectedProductId(data[0].id);
                }
            })
            .catch(err => console.error("Error cargando productos:", err));

        // Cargar tipo de cambio
        fetchExchangeRate()
            .then(rate => setExchangeRate(rate))
            .catch(err => {
                console.error("Error al cargar tipo de cambio:", err);
                setExchangeRate(0.266); // Respaldo (1 / 3.75 aprox)
            });
    }, []); // El array vacío significa "ejecutar solo al montar"

    // HOOK: useEffect (Consulta de DNI/RUC)
    useEffect(() => {
        // Limpia campos y error si se borra el input
        if (client.doc === '') {
            setClient(prev => ({ ...prev, nombres: '', apellidos: '' }));
            setNamesDisabled(false);
            setClientError('');
            return;
        }

        const docLength = client.doc.length;

        // Lógica para Boleta (DNI)
        if (!esFactura && docLength === 8) {
            setLoadingClient(true);
            setNamesDisabled(false);
            setClientError('');

            fetchReniecData(client.doc)
                .then(data => {
                    setClient(prev => ({
                        ...prev,
                        nombres: data.nombres,
                        apellidos: data.apellidos,
                    }));
                    setNamesDisabled(true);
                    setLoadingClient(false);
                })
                .catch(err => {
                    console.error(err);
                    setClientError(`Error DNI: ${err.message}. Ingrese datos manualmente.`);
                    setClient(prev => ({ ...prev, nombres: '', apellidos: '' }));
                    setNamesDisabled(false);
                    setLoadingClient(false);
                });
        }

        // Lógica para Factura (RUC)
        if (esFactura && docLength === 11) {
            setLoadingClient(true);
            setNamesDisabled(false);
            setClientError('');

            fetchSunatData(client.doc)
                .then(data => {
                    setClient(prev => ({
                        ...prev,
                        nombres: data.razonSocial, // api.js ya adapta "razon_social"
                        apellidos: '',
                    }));
                    setNamesDisabled(true);
                    setLoadingClient(false);
                })
                .catch(err => {
                    console.error(err);
                    setClientError(`Error RUC: ${err.message}. Ingrese datos manualmente.`);
                    setClient(prev => ({ ...prev, nombres: '', apellidos: '' }));
                    setNamesDisabled(false);
                    setLoadingClient(false);
                });
        }

    }, [client.doc, esFactura]); // Dependencias: se re-ejecuta si cambian

    // MANEJADORES DE EVENTOS

    const handleClientDocChange = (e) => {
        setClient({ ...client, doc: e.target.value });
        setNamesDisabled(false); // Desbloquea si empieza a editar
        setClientError(''); // Limpia error al escribir
    };

    const handleAddProduct = () => {
        if (cart.find(item => item.id === selectedProductId)) {
            alert("El producto ya está en el carrito.");
            return;
        }

        const productToAdd = products.find(p => p.id === selectedProductId);
        if (productToAdd) {
            setCart([...cart, { ...productToAdd, cantidad: 1 }]);
        }
    };

    const handleRemoveProduct = (id) => {
        setCart(cart.filter(item => item.id !== id));
    };

    const handleQuantityChange = (id, newQuantity) => {
        const qty = parseInt(newQuantity, 10);
        if (qty >= 1) {
            setCart(cart.map(item =>
                item.id === id ? { ...item, cantidad: qty } : item
            ));
        }
    };

    // Manejador de emisión de Boleta / Factura
    const handleEmitir = () => {
        setShowModal(true);
    };

    // Manejador para reiniciar la venta (limpiar todo)
    // Reemplaza tu función handleNewSale por esta:
    const handleNewSale = () => {
        // 1. Armamos el objeto de la venta
        const newSale = {
            id: Date.now(), // Usamos la fecha como ID único
            fecha: new Date().toLocaleString('es-PE'),
            tipo: esFactura ? 'Factura' : 'Boleta',
            cliente: {
                doc: client.doc,
                nombres: client.nombres,
                apellidos: client.apellidos || '' // Razón social no tiene apellidos
            },
            items: cart,
            totalSoles: totalSoles,
            totalDolares: totalDolares
        };

        // 2. Guardamos en el historial
        saveSale(newSale);

        // 3. Limpiamos todo (esto ya lo tenías)
        setShowModal(false);
        setCart([]);
        setClient({ doc: '', nombres: '', apellidos: '' });
        setClientError('');
        setNamesDisabled(false);

        alert("¡Venta registrada con éxito!");
    };
    // CÁLCULOS (Render)

    const calculateSubtotal = (item) => {
        return item.precio * item.cantidad;
    };

    const calculateTotal = () => {
        return cart.reduce((total, item) => total + calculateSubtotal(item), 0);
    };

    const totalSoles = calculateTotal();
    // El cálculo funciona gracias a que api.js devuelve (1 / venta)
    const totalDolares = totalSoles * exchangeRate;
    // Calculamos el T.C. original para mostrarlo (inverso de la tasa)
    const displayExchangeRate = exchangeRate > 0 ? (1 / exchangeRate) : 0;

    // Fecha actual para la boleta
    const fechaEmision = new Date().toLocaleDateString('es-PE', {
        year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit'
    });

    return (
        <div className="main-container billing-form" style={{ maxWidth: '800px' }}>
            <div className="d-flex justify-content-between align-items-center">
                <h2 className="text-primary">Generar {esFactura ? 'Factura' : 'Boleta'}</h2>
                <button className="btn btn-secondary" onClick={() => navigate('/dashboard')}>
                    &larr; Volver al Dashboard
                </button>
            </div>
            <hr />

            {/* SECCIÓN CLIENTE */}
            <h4>1. Datos del Cliente</h4>
            <div className="row">
                <div className="col-md-4 mb-3">
                    <label htmlFor="doc" className="form-label">
                        {esFactura ? 'RUC' : 'DNI'}
                    </label>
                    <input
                        type="text"
                        className={`form-control ${clientError ? 'is-invalid' : ''}`} // Muestra borde rojo si hay error
                        id="doc"
                        value={client.doc}
                        onChange={handleClientDocChange}
                        maxLength={esFactura ? 11 : 8}
                    />
                    {loadingClient && <div className="form-text">Consultando...</div>}
                    {/* Muestra el error de la API */}
                    {clientError && <div className="invalid-feedback d-block">{clientError}</div>}
                </div>
                <div className="col-md-8 mb-3">
                    <label htmlFor="nombres" className="form-label">
                        {esFactura ? 'Razón Social' : 'Nombres'}
                    </label>
                    <input
                        type="text"
                        className="form-control"
                        id="nombres"
                        value={client.nombres}
                        disabled={namesDisabled} // Se habilita/deshabilita según la API
                        onChange={(e) => setClient(p => ({ ...p, nombres: e.target.value }))} // Permite edición manual
                    />
                </div>
                {!esFactura && (
                    <div className="col-md-12 mb-3">
                        <label htmlFor="apellidos" className="form-label">Apellidos</label>
                        <input
                            type="text"
                            className="form-control"
                            id="apellidos"
                            value={client.apellidos}
                            disabled={namesDisabled} // Se habilita/deshabilita según la API
                            onChange={(e) => setClient(p => ({ ...p, apellidos: e.target.value }))} // Permite edición manual
                        />
                    </div>
                )}
            </div>

            {/* SECCIÓN PRODUCTOS */}
            <h4>2. Agregar Productos</h4>
            <div className="input-group mb-3">
                <select
                    className="form-select"
                    value={selectedProductId}
                    onChange={(e) => setSelectedProductId(e.target.value)}
                >
                    {products.map(p => (
                        <option key={p.id} value={p.id}>
                            {p.nombre} (S/ {p.precio.toFixed(2)})
                        </option>
                    ))}
                </select>
                <button className="btn btn-primary" type="button" onClick={handleAddProduct}>
                    Agregar
                </button>
            </div>

            {/* SECCIÓN CARRITO (Lista Temporal) */}
            <h4>3. Detalle de Venta</h4>
            <div className="list-group cart-list">
                {cart.length === 0 && (
                    <div className="list-group-item text-center text-muted">
                        No hay productos en la lista.
                    </div>
                )}

                {cart.map(item => (
                    <div key={item.id} className="list-group-item">
                        <div className="cart-item-details">
                            <strong>{item.nombre}</strong>
                            <br />
                            <small>P. Unit: S/ {item.precio.toFixed(2)}</small>
                        </div>
                        <input
                            type="number"
                            className="form-control cart-item-qty"
                            value={item.cantidad}
                            onChange={(e) => handleQuantityChange(item.id, e.target.value)}
                            min="1"
                        />
                        <span className="fw-bold me-3">
                            Sub: S/ {calculateSubtotal(item).toFixed(2)}
                        </span>
                        <button
                            className="btn btn-danger btn-sm"
                            onClick={() => handleRemoveProduct(item.id)}
                        >
                            &times;
                        </button>
                    </div>
                ))}
            </div>

            {/* SECCIÓN TOTALES */}
            <div className="total-section text-end">
                <h2>Total (SOLES): S/ {totalSoles.toFixed(2)}</h2>
                <h5>Total (DÓLARES): $ {totalDolares.toFixed(2)}</h5>
                {/* Mostrar el T.C. de forma legible (ej: 3.75) */}
                <small>(Tipo de Cambio Venta: 1 USD = {displayExchangeRate.toFixed(3)} PEN)</small>
                <br />
                <button
                    className="btn btn-success btn-lg mt-3"
                    onClick={handleEmitir}
                    disabled={cart.length === 0 || loadingClient || !client.doc}
                >
                    Emitir {esFactura ? 'Factura' : 'Boleta'}
                </button>
            </div>

            {/* TICKET PARA LA BOLETA / FACTURA */}
           {showModal && (
    <div className="modal show-custom" tabIndex="-1">
        <div className="modal-dialog modal-lg">
            <div className="modal-content">

                {/* Encabezado del Ticket */}
                <div className="modal-header bg-light" style={{ marginBottom: '0px' }}>
                    <h5 className="modal-title fw-bold">
                        {esFactura ? 'FACTURA ELECTRÓNICA' : 'BOLETA DE VENTA ELECTRÓNICA'}
                    </h5>
                    <button type="button" className="btn-close" onClick={() => setShowModal(false)}></button>
                </div>

                {/* === AQUÍ PONEMOS LA REFERENCIA (ticketRef) === */}
                {/* Esto es lo que saldrá en el PDF */}
                <div className="modal-body p-4" ref={ticketRef}>
                    
                    {/* ... (Todo el contenido de tu ticket sigue igual: Cabecera, Cliente, Tabla, Totales) ... */}
                    <div className="text-center mb-4">
                        <h4> "MI BODEGITA"</h4>
                        <p className="mb-0">RUC: 20123456789</p>
                        <p className="mb-0">Calle Lima 123, Ica</p>
                        <small className="text-muted">Fecha de Emisión: {fechaEmision}</small>
                    </div>
                    {/* ... Sigue tu código de tabla y totales aquí ... */}
                    {/* ... Para ahorrar espacio no copio todo, pero asegúrate de que el ref envuelva todo el contenido imprimible ... */}
                     <div className="border-top border-bottom py-3 mb-3">
                        {/* Tus datos de cliente... */}
                         <div className="row">
                            <div className="col-sm-6"><strong>Cliente:</strong> {client.nombres} {client.apellidos}</div>
                            <div className="col-sm-6 text-sm-end"><strong>{esFactura ? 'RUC' : 'DNI'}:</strong> {client.doc}</div>
                        </div>
                    </div>
                    <table className="table table-striped">
                         {/* Tu tabla de productos... */}
                        <thead><tr><th>Cant.</th><th>Producto</th><th className="text-end">P.Unit</th><th className="text-end">Importe</th></tr></thead>
                        <tbody>
                            {cart.map((item) => (
                                <tr key={item.id}>
                                    <td>{item.cantidad}</td>
                                    <td>{item.nombre}</td>
                                    <td className="text-end">{item.precio.toFixed(2)}</td>
                                    <td className="text-end">{calculateSubtotal(item).toFixed(2)}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                    <div className="row mt-4">
                         {/* Tus totales... */}
                         <div className="col-sm-12 text-end">
                            <h3 className="fw-bold text-primary">TOTAL: S/ {totalSoles.toFixed(2)}</h3>
                         </div>
                    </div>

                </div>
                {/* === FIN DEL ÁREA DEL PDF === */}

                {/* Pie del Modal con los BOTONES */}
                <div className="modal-footer">
                    <button type="button" className="btn btn-secondary" onClick={() => setShowModal(false)}>
                        Editar / Cerrar
                    </button>

                    {/* === NUEVO BOTÓN IMPRIMIR/DESCARGAR === */}
                    <button type="button" className="btn btn-success" onClick={handleDownloadPDF}>
                        <i className="bi bi-file-earmark-pdf"></i> Descargar PDF
                    </button>

                    <button type="button" className="btn btn-primary" onClick={handleNewSale}>
                        <i className="bi bi-check-circle"></i> Finalizar Venta
                    </button>
                </div>
            </div>
        </div>
    </div>
)}

        </div>
    );
};

export default BillingForm;