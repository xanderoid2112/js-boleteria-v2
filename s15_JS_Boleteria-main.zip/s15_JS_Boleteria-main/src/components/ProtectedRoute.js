import React from 'react';
import { Navigate } from 'react-router-dom';

const ProtectedRoute = ({ user, children }) => {
  if (!user) {
    // Si no hay usuario, redirige a la página de login
    return <Navigate to="/login" replace />;
  }

  // Si hay usuario, muestra el componente hijo (Dashboard, BillingForm, etc.)
  return children;
};

export default ProtectedRoute;