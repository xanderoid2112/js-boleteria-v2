import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { getSales } from '../services/sales'; // Reusamos tu servicio existente
import {
    Chart as ChartJS,
    CategoryScale,
    LinearScale,
    BarElement,
    Title,
    Tooltip,
    Legend,
    ArcElement
} from 'chart.js';
import { Bar, Doughnut } from 'react-chartjs-2';

// Registramos los componentes de Chart.js
ChartJS.register(
    CategoryScale,
    LinearScale,
    BarElement,
    Title,
    Tooltip,
    Legend,
    ArcElement
);

const SalesStats = () => {
    const navigate = useNavigate();

    // Estados para los datos de los gráficos
    const [salesByDate, setSalesByDate] = useState({
        labels: [],
        datasets: []
    });

    const [topProducts, setTopProducts] = useState({
        labels: [],
        datasets: []
    });

    useEffect(() => {
        // 1. Obtener las ventas del localStorage
        const allSales = getSales(); // Esto viene de tu sales.js

        // --- PROCESAMIENTO 1: VENTAS POR FECHA ---
        const salesMap = {};
        allSales.forEach(sale => {
            // Extraemos solo la fecha (dd/mm/yyyy) de la cadena de fecha completa
            const dateOnly = sale.fecha.split(',')[0];
            if (!salesMap[dateOnly]) {
                salesMap[dateOnly] = 0;
            }
            salesMap[dateOnly] += sale.totalSoles;
        });

        setSalesByDate({
            labels: Object.keys(salesMap), // Las fechas
            datasets: [
                {
                    label: 'Ingresos en Soles (S/)',
                    data: Object.values(salesMap), // Los montos
                    backgroundColor: 'rgba(53, 162, 235, 0.5)',
                },
            ],
        });

        // --- PROCESAMIENTO 2: PRODUCTOS MÁS VENDIDOS ---
        const productMap = {};
        allSales.forEach(sale => {
            sale.items.forEach(item => {
                if (!productMap[item.nombre]) {
                    productMap[item.nombre] = 0;
                }
                productMap[item.nombre] += item.cantidad;
            });
        });

        // Tomamos los 5 más vendidos para que el gráfico se vea bien
        const sortedProducts = Object.entries(productMap)
            .sort(([, a], [, b]) => b - a)
            .slice(0, 5);

        setTopProducts({
            labels: sortedProducts.map(([name]) => name),
            datasets: [
                {
                    label: 'Unidades Vendidas',
                    data: sortedProducts.map(([, qty]) => qty),
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.5)',
                        'rgba(54, 162, 235, 0.5)',
                        'rgba(255, 206, 86, 0.5)',
                        'rgba(75, 192, 192, 0.5)',
                        'rgba(153, 102, 255, 0.5)',
                    ],
                    borderWidth: 1,
                },
            ],
        });

    }, []);

    return (
        <div className="main-container">
            <div className="d-flex justify-content-between align-items-center mb-4">
                <h2 className="text-primary"><i className="bi bi-bar-chart-line"></i> Estadísticas de Ventas</h2>
                <button className="btn btn-secondary" onClick={() => navigate('/dashboard')}>
                    &larr; Volver al Dashboard
                </button>
            </div>

            <div className="row">
                {/* Gráfico de Barras */}
                <div className="col-md-8 mb-4">
                    <div className="card shadow-sm p-3">
                        <h5 className="text-center text-muted mb-3">Ingresos por Día</h5>
                        <Bar options={{ responsive: true }} data={salesByDate} />
                    </div>
                </div>

                {/* Gráfico de Dona */}
                <div className="col-md-4 mb-4">
                    <div className="card shadow-sm p-3">
                        <h5 className="text-center text-muted mb-3">Top 5 Productos</h5>
                        <div className="d-flex justify-content-center">
                            <div style={{ width: '100%', maxWidth: '300px' }}>
                                <Doughnut data={topProducts} />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default SalesStats;