import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { fetchReniecData } from '../services/api';
import { registerUser } from '../services/auth';

const Register = () => {
    // HOOK: useState
    // Maneja el estado completo del formulario en un solo objeto.
    const [formData, setFormData] = useState({
        dni: '',
        nombres: '',
        apellidos: '',
        correo: '',
        usuario: '',
        contraseña: '',
    });

    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');
    const [success, setSuccess] = useState('');

    // Estado para bloquear los campos de nombre y apellido
    const [namesDisabled, setNamesDisabled] = useState(false);

    const navigate = useNavigate();

    // HOOK: useEffect
    // Este hook "escucha" cambios en el DNI.
    // Cuando el DNI tiene 8 dígitos, llama a la API real.
    useEffect(() => {
        if (formData.dni.length === 8) {
            setLoading(true);
            setNamesDisabled(false); // Desbloquea por si acaso
            setError(''); // Limpia errores anteriores

            fetchReniecData(formData.dni)
                .then(data => {
                    setFormData(prev => ({
                        ...prev,
                        nombres: data.nombres,
                        apellidos: data.apellidos,
                    }));
                    setNamesDisabled(true); // Bloquea los campos
                    setLoading(false);
                })
                .catch(err => {
                    console.error(err);
                    // Mostramos el error y permitimos ingreso manual
                    setError(`Error al consultar DNI: ${err.message}. Por favor, ingrese los datos manualmente.`);
                    setLoading(false);
                    setNamesDisabled(false); // Permite ingreso manual si falla
                });
        } else {
            // Si el DNI no tiene 8 dígitos, resetea y desbloquea
            setFormData(prev => ({ ...prev, nombres: '', apellidos: '' }));
            setNamesDisabled(false);
            setError(''); // Limpia el error si el usuario está corrigiendo el DNI
        }
    }, [formData.dni]); // Dependencia: se ejecuta solo si 'formData.dni' cambia

    // Manejador genérico para todos los inputs
    const handleChange = (e) => {
        const { id, value } = e.target;
        setFormData(prev => ({
            ...prev,
            [id]: value,
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');
        setSuccess('');

        try {
            await registerUser(formData);
            setSuccess('¡Registro exitoso! Ahora puedes iniciar sesión.');
            // Limpiar formulario
            setFormData({
                dni: '', nombres: '', apellidos: '',
                correo: '', usuario: '', contraseña: '',
            });
            setNamesDisabled(false);
            // Redirigir a login después de unos segundos
            setTimeout(() => navigate('/login'), 1000);
        } catch (err) {
            setError(err.message);
        }
    };

    return (
        <div className="main-container">
            <h2 className="text-center text-primary mb-4">Registro de Administrador</h2>
            <form onSubmit={handleSubmit}>
                {/* Esta línea mostrará el error de la API si falla */}
                {error && <div className="alert alert-danger">{error}</div>}
                {success && <div className="alert alert-success">{success}</div>}

                <div className="mb-3">
                    <label htmlFor="dni" className="form-label">DNI</label>
                    <input
                        type="text"
                        className="form-control"
                        id="dni"
                        maxLength="8"
                        value={formData.dni}
                        onChange={handleChange}
                        required
                    />
                    {loading && <div className="form-text">Consultando RENIEC...</div>}
                </div>

                <div className="row">
                    <div className="col-md-6 mb-3">
                        <label htmlFor="nombres" className="form-label">Nombres</label>
                        <input
                            type="text"
                            className="form-control"
                            id="nombres"
                            value={formData.nombres}
                            onChange={handleChange}
                            disabled={namesDisabled} // Campo bloqueado/desbloqueado por la API
                            required
                        />
                    </div>
                    <div className="col-md-6 mb-3">
                        <label htmlFor="apellidos" className="form-label">Apellidos</label>
                        <input
                            type="text"
                            className="form-control"
                            id="apellidos"
                            value={formData.apellidos}
                            onChange={handleChange}
                            disabled={namesDisabled} // Campo bloqueado/desbloqueado por la API
                            required
                        />
                    </div>
                </div>

                <div className="mb-3">
                    <label htmlFor="correo" className="form-label">Correo Electrónico</label>
                    <input
                        type="email"
                        className="form-control"
                        id="correo"
                        value={formData.correo}
                        onChange={handleChange}
                        required
                    />
                </div>

                <div className="mb-3">
                    <label htmlFor="usuario" className="form-label">Usuario</label>
                    <input
                        type="text"
                        className="form-control"
                        id="usuario"
                        value={formData.usuario}
                        onChange={handleChange}
                        required
                    />
                </div>

                <div className="mb-3">
                    <label htmlFor="contraseña" className="form-label">Contraseña</label>
                    <input
                        type="password"
                        className="form-control"
                        id="contraseña"
                        value={formData.contraseña}
                        onChange={handleChange}
                        required
                    />
                </div>

                <div className="d-grid gap-2">
                    <button type="submit" className="btn btn-success btn-lg" disabled={loading}>
                        Registrarme
                    </button>
                </div>
            </form>
            <div className="text-center mt-3">
                <p>¿Ya tienes cuenta? <Link to="/login">Inicia sesión</Link></p>
            </div>
        </div>
    );
};

export default Register;