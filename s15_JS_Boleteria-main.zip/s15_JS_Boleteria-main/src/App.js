import React, { useState } from 'react';
import './App.css';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import Login from './components/Login';
import Register from './components/Register';
import Dashboard from './components/Dashboard';
import BillingForm from './components/BillingForm';
import ProtectedRoute from './components/ProtectedRoute'; // Importamos la ruta protegida
import { getCurrentUser, logoutUser } from './services/auth';
import SalesHistory from './components/SalesHistory';
import Products from './components/Products';
import SalesStats from './components/SalesStats';

function App() {
  // HOOK: useState
  // Maneja el estado global de la autenticación.
  // Obtiene la sesión guardada al recargar la página.
  const [currentUser, setCurrentUser] = useState(getCurrentUser());

  const handleLogin = (user) => {
    setCurrentUser(user);
  };

  const handleLogout = () => {
    logoutUser();
    setCurrentUser(null);
  };

  return (
    <BrowserRouter>
      <div className="container mt-4">
        <Routes>
          {/* Rutas Públicas (Login y Registro) */}
          <Route path="/login" element={<Login onLoginSuccess={handleLogin} />} />
          <Route path="/register" element={<Register />} />

          {/* Ruta Raíz */}
          {/* Si está logueado, va al dashboard. Si no, al login. */}
          <Route
            path="/"
            element={
              currentUser
                ? <Navigate to="/dashboard" />
                : <Navigate to="/login" />
            }
          />

          {/* Rutas Protegidas (Requieren Login) */}
          <Route
            path="/dashboard"
            element={
              <ProtectedRoute user={currentUser}>
                <Dashboard user={currentUser} onLogout={handleLogout} />
              </ProtectedRoute>
            }
          />

          <Route
            path="/stats"
            element={
              <ProtectedRoute user={currentUser}>
                <SalesStats />
              </ProtectedRoute>
            }
          />

          <Route
            path="/products"
            element={
              <ProtectedRoute user={currentUser}>
                <Products />
              </ProtectedRoute>
            }
          />

          <Route
            path="/history"
            element={
              <ProtectedRoute user={currentUser}>
                <SalesHistory />
              </ProtectedRoute>
            }
          />
          <Route
            path="/billing/:tipo" // :tipo será "boleta" o "factura"
            element={
              <ProtectedRoute user={currentUser}>
                <BillingForm />
              </ProtectedRoute>
            }
          />

          {/* Ruta de "catch-all" (puedes crear un componente 404) */}
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </div>
    </BrowserRouter>
  );
}

export default App;
